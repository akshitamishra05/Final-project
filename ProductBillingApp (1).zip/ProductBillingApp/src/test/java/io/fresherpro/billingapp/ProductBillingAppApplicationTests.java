package io.fresherpro.billingapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProductBillingAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
