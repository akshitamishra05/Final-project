package io.fresherpro.billingapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProductBillingAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProductBillingAppApplication.class, args);
	}

}
