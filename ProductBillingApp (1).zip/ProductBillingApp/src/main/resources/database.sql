CREATE TABLE product(
product_code INTEGER PRIMARY KEY auto_increment,
product_name VARCHAR(30),
product_price int,
product_gst int);
INSERT INTO product VALUES(1,'Lenovo Laptop',30000,10);
INSERT INTO product VALUES(2,'Dell Laptop',38000,10);
INSERT INTO product VALUES(3,'Asus Laptop',50000,15);
INSERT INTO product VALUES(4,'OnePlus 8',40000,5);
INSERT INTO product VALUES(5,'Realme X2 Pro',33000,5);
INSERT INTO product VALUES(6,'Realme XT',17000,2);